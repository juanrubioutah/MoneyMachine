package conrad.weiser.robinhood.api.endpoint.account.methods;

import conrad.weiser.robinhood.api.endpoint.account.Account;
import conrad.weiser.robinhood.api.request.RequestMethod;
import conrad.weiser.robinhood.api.endpoint.account.data.AccountHolderEmploymentElement;
import conrad.weiser.robinhood.api.parameters.HttpHeaderParameter;

public class GetAccountHolderEmploymentInfo extends Account {
	
	public GetAccountHolderEmploymentInfo() {
		
		this.setUrlBase("https://api.robinhood.com/user/employment/");
		
		//Add the headers into the request
		this.addHttpHeaderParameter(new HttpHeaderParameter("Accept", "application/json"));
		
		//This method is ran as GET
		this.setMethod(RequestMethod.GET);
		
		//Declare what the response should look like
		this.setReturnType(AccountHolderEmploymentElement.class);
	}

}
