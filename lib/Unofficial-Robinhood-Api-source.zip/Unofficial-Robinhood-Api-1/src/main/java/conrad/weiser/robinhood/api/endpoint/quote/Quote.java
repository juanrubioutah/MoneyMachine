package conrad.weiser.robinhood.api.endpoint.quote;

import conrad.weiser.robinhood.api.ApiMethod;

/**
 * Created by SirensBell on 6/19/2017.
 */
public class Quote extends ApiMethod {

    protected Quote() {

        super("Quote");
    }
}
