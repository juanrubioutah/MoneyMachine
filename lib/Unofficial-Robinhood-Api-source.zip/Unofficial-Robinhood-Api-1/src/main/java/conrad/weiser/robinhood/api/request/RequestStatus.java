package conrad.weiser.robinhood.api.request;

public enum RequestStatus {
	
	SUCCESS,
	FAILURE,
	NOT_LOGGED_IN

}
