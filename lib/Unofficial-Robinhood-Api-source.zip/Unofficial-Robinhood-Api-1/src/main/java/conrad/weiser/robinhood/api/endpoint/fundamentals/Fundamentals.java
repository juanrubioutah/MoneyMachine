package conrad.weiser.robinhood.api.endpoint.fundamentals;

import conrad.weiser.robinhood.api.ApiMethod;

public class Fundamentals extends ApiMethod {
	
	protected Fundamentals() {
		
		super("fundamentals");
	}

}
