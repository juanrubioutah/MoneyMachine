package conrad.weiser.robinhood.api.endpoint.orders.enums;

public enum OrderTrigger {
	
	IMMEDIATE,
	STOP

}
