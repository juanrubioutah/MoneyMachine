package conrad.weiser.robinhood.api.endpoint.account.data.enums;

public enum LiquidityNeeds {
	
	NOT_IMPORTANT_LIQUIDITY_NEED,
	SOMEWHAT_IMPORTANT_LIQUIDITY_NEED,
	VERY_IMPORTANT_LIQUIDITY_NEED,
	ERROR

}
