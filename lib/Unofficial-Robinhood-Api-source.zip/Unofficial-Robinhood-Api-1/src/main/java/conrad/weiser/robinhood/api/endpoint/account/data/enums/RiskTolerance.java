package conrad.weiser.robinhood.api.endpoint.account.data.enums;

public enum RiskTolerance {
	
	LOW_RISK_TOLERANCE,
	MED_RISK_TOLERANCE,
	HIGH_RISK_TOLERANCE,
	ERROR

}
