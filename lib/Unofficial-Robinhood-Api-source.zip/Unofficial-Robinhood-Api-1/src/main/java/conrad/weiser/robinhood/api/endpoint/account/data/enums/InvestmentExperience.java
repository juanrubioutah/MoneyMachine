package conrad.weiser.robinhood.api.endpoint.account.data.enums;

public enum InvestmentExperience {
	
	EXTENSIVE_INVESTMENT_EXPERIENCE,
	GOOD_INVESTMENT_EXPERIENCE,
	LIMITED_INVESTMENT_EXPERIENCE,
	NO_INVESTMENT_EXPERIENCE,
	ERROR

}
