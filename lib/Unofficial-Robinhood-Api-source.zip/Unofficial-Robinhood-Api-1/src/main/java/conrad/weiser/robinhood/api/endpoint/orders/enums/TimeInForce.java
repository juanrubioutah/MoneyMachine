package conrad.weiser.robinhood.api.endpoint.orders.enums;

public enum TimeInForce {
	
	GOOD_FOR_DAY,
	GOOD_UNTIL_CANCELED,
	IMMEDIATE_OR_CANCEL,
	FILL_OR_KILL,
	ON_MARKET_OPEN
	

}
