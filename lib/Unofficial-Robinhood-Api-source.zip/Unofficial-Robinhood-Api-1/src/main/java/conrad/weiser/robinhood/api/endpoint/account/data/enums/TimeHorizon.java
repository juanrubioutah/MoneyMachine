package conrad.weiser.robinhood.api.endpoint.account.data.enums;

public enum TimeHorizon {
	
	SHORT_TIME_HORIZON,
	MEDIUM_TIME_HORIZON,
	LONG_TIME_HORIZON,
	ERROR

}
